
public class EstruturaRepeticao {

	public static void main(String[] args) {

		// for( "inicializar"; "condicao de parada" ; "incremento") {
		//
		// }

//		for (int contador = 0; contador < 10; contador++) {
//			System.out.println("Preste atencao" + contador);
//		}
//
//		int contador = 20;
//
//		while (contador < 10) {
//
//			contador++;
//		}
//
//		do {
//
//			System.out.println(" ");
//
//		} while (contador < 10);

//		String vet [] = new String[10];

//		
//		for (String i : vet) {
//			System.out.println(i);
//		}

//		for (int i = 0; i < 5; i++) {
//			System.out.println("Preste atencao");
//		}
		
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 500; j++) {
				for (int j2 = 0; j2 < 1000; j2++) {
					System.out.println("i: "+ i + " j: "+ j);
					
				}
			}
		}
	}
}
