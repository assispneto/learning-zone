
public class Banco {

	public String nome;

	public Banco(String nome) {
		this.nome = nome;
	}

}
