
public class Aluno {

	//atributos
	 public int matricula;
	 public String cpf;
	 public String nome;
	
	 public Conta conta;
	 
	 
	 public Aluno(int matricula, String cpf, String nome) {
		this.matricula = matricula;
		this.cpf = cpf;
		this.nome = nome;
	}
	 
	 
	
	 
	 
	 
}
