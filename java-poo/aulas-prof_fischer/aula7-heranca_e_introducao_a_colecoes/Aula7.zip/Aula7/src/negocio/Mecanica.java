package negocio;

public class Mecanica  extends Produto{

	public Mecanica(int id, String nome) {
		super(id, nome);
		// TODO Auto-generated constructor stub
	}

}
