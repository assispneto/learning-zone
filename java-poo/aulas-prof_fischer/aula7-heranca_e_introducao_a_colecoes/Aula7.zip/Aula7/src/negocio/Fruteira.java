package negocio;

public class Fruteira  extends Produto {

	public Fruteira(int id, String nome) {
		super(id, nome);
		// TODO Auto-generated constructor stub
	}

}
