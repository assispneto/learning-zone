package negocio;

public class Valor {

	private float base;
	private float lucro;
	private float imposto;
}
