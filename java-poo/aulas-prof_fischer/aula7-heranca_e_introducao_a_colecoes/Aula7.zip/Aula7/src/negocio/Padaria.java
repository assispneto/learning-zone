package negocio;

public class Padaria extends Produto{

	public Padaria(int id, String nome) {
		super(id, nome);
		// TODO Auto-generated constructor stub
	}

}
