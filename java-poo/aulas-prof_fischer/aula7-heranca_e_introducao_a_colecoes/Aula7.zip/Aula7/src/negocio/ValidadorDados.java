package negocio;

public class ValidadorDados {

	
	public boolean validarDados(int id) {
		
		if(id >0 )
		return true;
		
		return false;
	}
}
